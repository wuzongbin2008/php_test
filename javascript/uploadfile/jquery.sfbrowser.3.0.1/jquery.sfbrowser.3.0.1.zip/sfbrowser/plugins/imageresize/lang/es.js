// author: Juan Razeto
$.sfbrowser.addLang({
	 resize:				"Redimensionar"
	,scale:					"Escala"
	,crop:					"Crop"
	,result:				"Result"
	,width:					"Anchura"
	,height:				"Altura"
	,imgResize:				"Cambia el tama�o de la imagen"
	,imgResized:			"El tama�o de la imagen"
	,imgNotresized:			"El tama�o de imagen no"
});