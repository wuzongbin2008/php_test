// author: Ron Valstar
$.sfbrowser.addLang({
	 resize:				"Verschaal"
	,scale:					"Schaal"
	,crop:					"Uitsnede"
	,result:				"Resultaat"
	,width:					"Breedte"
	,height:				"Hoogte"
	,imgResize:				"Verschaal afbeelding"
	,imgResized:			"Afbeelding verschaalt"
	,imgNotresized:			"Verschalen mislukt"
});