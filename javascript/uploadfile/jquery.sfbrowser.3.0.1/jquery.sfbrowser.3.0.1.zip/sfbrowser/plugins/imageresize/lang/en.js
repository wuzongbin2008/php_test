// author: Ron Valstar
$.sfbrowser.addLang({
	 resize:				"Resize"
	,scale:					"Scale"
	,crop:					"Crop"
	,result:				"Result"
	,width:					"Width"
	,height:				"Height"
	,imgResize:				"Resize image"
	,imgResized:			"Image resized"
	,imgNotresized:			"Image resize failed"
});