$(function() {
	$("html").remove();
});