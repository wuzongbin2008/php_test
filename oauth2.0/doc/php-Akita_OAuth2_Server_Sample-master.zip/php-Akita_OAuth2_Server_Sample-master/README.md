php-Akita_OAuth2_Server_Sample
======================================================
This is sample Server and Client using php-Akita_OAuth2.

USAGE
------------------------------------------------------
$ cd /var/www/html

$ git clone  git://github.com/ritou/php-Akita_OAuth2_Server_Sample.git

$ git clone  git://github.com/ritou/php-Akita_OAuth2.git

setup mongodb as default config

access http://yourlocalhost/php-Akita_OAuth2_Server_Sample

AUTHOR
------------------------------------------------------
@ritou ritou@gmail.com

LISENCE
------------------------------------------------------
MIT Lisense.
