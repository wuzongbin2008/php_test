# OAuth2
OAuth认证服务器(基于OAuth2.0)

client注册使用cli, 外部不可访问;

Yaf框架
暂支持授权码模式＋简化模式
默认为授权码模式