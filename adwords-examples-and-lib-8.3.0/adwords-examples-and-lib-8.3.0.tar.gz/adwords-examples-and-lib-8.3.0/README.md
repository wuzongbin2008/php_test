### AdWords API PHP Client Library Examples

For instructions on how to get started, please visit our GitHub project:
https://github.com/googleads/googleads-php-lib

For API and client library updates and news, please follow our
[Google+ Ads Developers page](https://plus.google.com/+GoogleAdsDevelopers/posts)
and our [Google Ads Developers blog](http://googleadsdeveloper.blogspot.com/).

For any issues relating to the API in general (not this library), please see the
[AdWords API forum](https://groups.google.com/forum/#!forum/adwords-api)

